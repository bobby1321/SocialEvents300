import java.util.Date;

public class RssFeedModel {
	private String title;
	private String link;
    private String description;
    private Date timestamp;
    private String organization;
    private String location;
    private double latitude = 0.0;
    private double longitude = 0.0;
    

    public RssFeedModel(String title, String link, String description, Date timestamp) {
        this.title = title;
        this.link = link;
        this.timestamp = timestamp;
        int loc = description.indexOf("<b>Organization</b>");
        if (loc != -1){
            organization = description.substring(loc+29);
        }
        int loc2 = description.indexOf("<br/>");
        if (loc2 != -1) {
        	location = description.substring(0, loc2);
        }
        this.description = description.substring(loc2, loc);
        location = location.trim();
    }
    
    public String toString() {
    	String string = title + " // " +  organization + " // " + location + " // " + timestamp.toString();
    	return string;
    }
    
    public String getTitle() {
		return title;
	}

	public String getLink() {
		return link;
	}

	public String getDescription() {
		return description;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public String getOrganization() {
		return organization;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
}
