import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.io.SyndFeedInput;
import com.sun.syndication.io.XmlReader;

public class ReadTest {
	
	private static File locationFile = new File("locations.csv");
	
    @SuppressWarnings("rawtypes")
	public static void main(String[] args) {
    	
        List<RssFeedModel> RssModelList = new ArrayList<RssFeedModel>();
    	URL feedSource;
    	SyndFeed feed = null;
    	Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
			//System.out.println("YAY");
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			feedSource = new URL("https://25livepub.collegenet.com/calendars/db-campus-events-db-student-org-events.rss");
			SyndFeedInput input = new SyndFeedInput();
	    	feed = input.build(new XmlReader(feedSource));
	    	 for (Iterator iterator = feed.getEntries().iterator(); iterator
	    	          .hasNext();) {
	    	        SyndEntry syndEntry = (SyndEntry) iterator.next();
	    	        if (syndEntry.getPublishedDate().after(new Date())) {
	    	        	RssModelList.add(new RssFeedModel(
	    	        			syndEntry.getTitle(),
	    	        			syndEntry.getLink(),
	    	        			syndEntry.getDescription().getValue(), 
	    	        			syndEntry.getPublishedDate()
	    	        			));
	    	        }
	    	      }
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (Exception f) {
			f.printStackTrace();
		}
		
		try {
			
			FileReader fileReader = new FileReader(locationFile);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			CSVParser csvParser = new CSVParser(bufferedReader, CSVFormat.DEFAULT); 
			String line;
			for (RssFeedModel r : RssModelList) {
				for (CSVRecord csvRecord : csvParser) {
					String compareLocation = csvRecord.get(0) + " - " + csvRecord.get(1) + " - " + csvRecord.get(2);
					if (compareLocation.equalsIgnoreCase(r.getLocation())) {
						try {
							r.setLatitude(Double.parseDouble(csvRecord.get(3)));
							r.setLongitude(Double.parseDouble(csvRecord.get(4)));
						} catch(Exception e) {}				
					}
				}
				fileReader.close();
				fileReader = new FileReader(locationFile);
				bufferedReader = new BufferedReader(fileReader);
				csvParser = new CSVParser(bufferedReader, CSVFormat.DEFAULT);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
            String sq = "INSERT INTO table1 (title,description,timestamp,organization,location,latitude,longitude,link) VALUES (?,?,?,?,?,?,?,?)";
            PreparedStatement pr = con.prepareStatement(sq);
            for(int i=0;i<RssModelList.size();i++){
                pr.setString(1,RssModelList.get(i).getTitle());
                pr.setString(2,RssModelList.get(i).getDescription());
                pr.setString(3,new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(RssModelList.get(i).getTimestamp()));
                pr.setString(4,RssModelList.get(i).getOrganization());
                pr.setString(5,RssModelList.get(i).getLocation());
                pr.setString(6,Double.toString(RssModelList.get(i).getLatitude()));
                pr.setString(7,Double.toString(RssModelList.get(i).getLongitude()));
                pr.setString(8,RssModelList.get(i).getLink());
                pr.execute();
            }            
        } catch (SQLException ex) {
        	ex.printStackTrace();
        }
    }
}