Social Events 300 - ERAU social event viewing app

The goal of this project is to create a better way to view events that occur on the Embry-Riddle Campus.

Due to the nature of this application, there are two main pieces of code: the server-side RSS feed parsing and MySQL database, and the client-side Android app.

1) Sever-side code

In the "Server Stuff" folder, you will find a few items;
(Note: every file in this folder can be opened in Notepad without any problems)

a) CreateTableCommand.txt: This is just the MySQL command to create the table that all of the events are stored in. Its purpose is just to be there in case the table gets deleted, so that it can be copied back in.

b) moveDataToTable.bash: This file is the one that is run every 10 minutes on the server. It just runs the Table_Maker.jar, which adds the parsed RSS feed data to the MySQL database, preping it for being read by the PHP scripts.

c) Table_Maker.jar: This is the RSS parsing Java programs compiled into a runnable jar file, which is then run by moveDataToTable.jar

d) PHP Scripts: This folder contains all of the PHP scripts that the app accesses on the server. Each is named with its functionality, except for event_array.php, which is just the default list of all events before filtering. 

e) Eclipse Project: This folder contains all of the source code for Table_Maker.jar. To open in Eclipse, select THIS folder as the workspace, NOT the ones inside it. The program will not run outside of the server environment, as that's where the MySQL database is located.


2) Client-side code

The "SocialEvents300" folder is the root folder for the Android app. In Android Studio, select this folder as the project folder. Make sure you have Android Studio updated to version 3.6.1. All of the files necessary to run the app are contained in this folder. You can run it on a virtual device through Android Studio, or you can upload it to any Android Phone. AR will not work on a virtual device.




Git-Hub Repo: https://github.com/bobby1321/SocialEvents300

The Git-Hub contains all of the code history for the Client-Side of the project


If there are any issues with the project feel free to contact me with questions